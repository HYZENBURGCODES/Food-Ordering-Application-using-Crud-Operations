package food_application.foodapp.Model;

import sun.security.util.Length;

import javax.persistence.*;

@Entity
@Table(name = "reviews")
public class Reviews
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Reviews_ID;

    private String email;

    @Column(length = 1000)
    private String Review;

    private String Date_and_time;

    public Reviews(Long reviews_ID, String email, String review, String date_and_time) {
        Reviews_ID = reviews_ID;
        this.email = email;
        Review = review;
        Date_and_time = date_and_time;
    }

    public Reviews() {
    }

    public Long getReviews_ID() {
        return Reviews_ID;
    }

    public void setReviews_ID(Long reviews_ID) {
        Reviews_ID = reviews_ID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getReview() {
        return Review;
    }

    public void setReview(String review) {
        Review = review;
    }

    public String getDate_and_time() {
        return Date_and_time;
    }

    public void setDate_and_time(String date_and_time) {
        Date_and_time = date_and_time;
    }
}
