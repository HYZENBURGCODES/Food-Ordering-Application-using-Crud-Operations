package food_application.foodapp.Controller;


import food_application.foodapp.Model.*;
import food_application.foodapp.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserController
{
    @Autowired
    FoodService foodService;

    @Autowired
    OrderService orderService;

    @Autowired
    UserService userService;

    @Autowired
    ReviewService reviewService;

    @Autowired
    ContactService contactService;

    @GetMapping(value = "/userfoodlist")
    public String viewfooduser(Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("viewfoodlistuser");
        List<Food> foodList=foodService.getAllFoods();
        model.addAttribute("userfoodlist",foodList);
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "viewfoodlistuser";
    }

    @GetMapping(value = "/checkout/{id}")
    public String Chekout(@PathVariable("id") Long id,Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("CheckOut");
        Optional<Food>foodOptional=foodService.getFoodByID(id);
        model.addAttribute("id",foodOptional.get().getId());
        model.addAttribute("name",foodOptional.get().getName());
        model.addAttribute("details",foodOptional.get().getDesignation());
        model.addAttribute("img",foodOptional.get().getFileName());
        model.addAttribute("price",foodOptional.get().getPrice());

        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);

        return "CheckOut";

    }

    @PostMapping(value = "/placeorder")
    public String make_order(@Valid Order order, @RequestParam("firstname")String firstname, @RequestParam("lastname") String lastname,
                             @RequestParam("address") String address, @RequestParam("city") String city,
                             @RequestParam("contact") String contact, @RequestParam("price")int price, @RequestParam("qty")int qty,
                             @RequestParam("foodname") String foodname,Model model)
    {
        try
        {
            order.setFirstname(firstname);
            order.setLastname(lastname);
            order.setAddress(address);
            order.setCity(city);

            Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
            UserDetails userDetails=(UserDetails)authentication.getPrincipal();
            order.setEmail(userDetails.getUsername());

            order.setContact(contact);
            order.setStatus("Preparing");
            order.setPrice(price);
            order.setQnty(qty);
            int total= (price*qty)+100;
            order.setTotal(total);
            order.setFoodname(foodname);

            DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime localDateTime=LocalDateTime.now();
            order.setDate(dateTimeFormatter.format(localDateTime));

            orderService.saveOrder(order);
            model.addAttribute("foodname",order.getFoodname());

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

         model.addAttribute("foodname",foodname);
         model.addAttribute("qty",qty);
         model.addAttribute("address",address);
         model.addAttribute("price",price);
         model.addAttribute("total",(price*qty)+100);
         model.addAttribute("firstname",firstname);
         model.addAttribute("lastname",lastname);
        return "OrderConfirmation";
    }

    @GetMapping(value = "/viewprofile/{email}")
    public String ViewUserDetails(@PathVariable String email,Model model)
    {
        ModelAndView detailsview=new ModelAndView();
        detailsview.setViewName("ViewCustomerProfile");
        User userdetails=userService.getUserByEmail(email);
        model.addAttribute("userdetails",userdetails);

        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "ViewCustomerProfile";
    }

    @PostMapping(value = "/addreview")
    public String Add_Reviews(@Valid Reviews reviews,@RequestParam ("review") String review)
    {
        try
        {
            if (reviews==null)
            {
                return "redirect:/user/addreviewpage?reviewunsuccess";
            }
            reviews.setReview(review);

            Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
            UserDetails userDetails=(UserDetails)authentication.getPrincipal();
            reviews.setEmail(userDetails.getUsername());

            DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime localDateTime=LocalDateTime.now();
            reviews.setDate_and_time(dateTimeFormatter.format(localDateTime));

            boolean status=reviewService.AddReviews(reviews);
            if(status)
            {
                return "redirect:/user/addreviewpage?reviewsuccess";
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return "redirect:/user/addreviewpage?reviewunsuccess";
    }

    @GetMapping(value = "/addreviewpage")
    public String AddReviewsPage(Model model)
    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "addReviews";
    }

    @RequestMapping(value = "/viewallreviews")
    public String viewAllReviews(Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("ViewReviewsUser");
        List<Reviews> reviewsList=reviewService.getAllReviews();
        model.addAttribute("reviewsList",reviewsList);
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "ViewReviewsUser";
    }

    @GetMapping(value = "/contactpage")
    public String ContactPage(Model model)
    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "UserContact";
    }

    @PostMapping(value = "/contact")
    public String contact(@Valid Contact contact, @RequestParam ("msge") String msge) {
        try {
            if (contact == null) {
                return "redirect:/user/contactpage?contactunsuccess";
            }
            contact.setMessage(msge);

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            contact.setEmail(userDetails.getUsername());

            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime localDateTime = LocalDateTime.now();
            contact.setDate(dateTimeFormatter.format(localDateTime));

            boolean message = contactService.AddReviews(contact);
            if (message) {
                return "redirect:/user/contactpage?contactsuccess";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/user/contactpage?contactunsuccess";
    }

    @GetMapping(value = "/update/{id}")
    public String UpdateStatus(@PathVariable("id") Long id,Model model)
    {
        Optional<Order> orderdetails=orderService.getOrderByID(id);
        model.addAttribute("id",orderdetails.get().getOrder_id());
        model.addAttribute("address",orderdetails.get().getAddress());
        model.addAttribute("city",orderdetails.get().getCity());
        model.addAttribute("contact",orderdetails.get().getContact());
        model.addAttribute("email",orderdetails.get().getEmail());
        model.addAttribute("firstname",orderdetails.get().getFirstname());
        model.addAttribute("foodname",orderdetails.get().getFoodname());
        model.addAttribute("lastname",orderdetails.get().getLastname());
        model.addAttribute("price",orderdetails.get().getPrice());
        model.addAttribute("quantity",orderdetails.get().getQnty());
        model.addAttribute("status",orderdetails.get().getStatus());
        model.addAttribute("total",orderdetails.get().getTotal());
        model.addAttribute("date",orderdetails.get().getDate());
        return "OrderDetailsUser";
    }

    @PostMapping(value = "/updateorder")
    public String Update_Order(@Valid Order order, @RequestParam("order_id")Long id,@RequestParam("firstname")String firstname, @RequestParam("lastname") String lastname,
                               @RequestParam("address") String address, @RequestParam("city") String city,
                               @RequestParam("contact") String contact, @RequestParam("price")int price, @RequestParam("qnty")int qty,
                               @RequestParam("foodname") String foodname,@RequestParam("email")String email,@RequestParam("updatestatus")String status,@RequestParam("total")int total,
                               @RequestParam("date")String date, Model model)
    {
        try
        {
            order.setOrder_id(id);
            order.setFirstname(firstname);
            order.setLastname(lastname);
            order.setAddress(address);
            order.setCity(city);
            order.setContact(contact);
            order.setStatus(status);
            order.setPrice(price);
            order.setQnty(qty);
            order.setTotal(total);
            order.setFoodname(foodname);
            order.setDate(date);
            order.setEmail(email);
            orderService.saveOrder(order);
            Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
            UserDetails userDetails=(UserDetails)authentication.getPrincipal();
            model.addAttribute("useremail",userDetails);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "OnTheWayOrdersUser";
    }
    @RequestMapping(value = "/viewneworders/{email}/{status}")
    public String viewneworderlist(@PathVariable ("email")String email, @PathVariable("status") String status, Model model)
    {
        ModelAndView orderview=new ModelAndView();
        orderview.setViewName("ViewCustomerOrders");
        List<Order> customerorderlist=orderService.getOrderByEmailAndStatus(email,status);
        model.addAttribute("customerorderlist",customerorderlist);
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "ViewCustomerOrders";
    }

    @RequestMapping(value = "/viewonthewayorders/{email}/{status}")
    public String viewonthewayorderlist(@PathVariable ("email")String email, @PathVariable("status") String status, Model model)
    {
        List<Order> customerorderlist=orderService.getOrderByEmailAndStatus(email,status);
        model.addAttribute("customerorderlist",customerorderlist);
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "OnTheWayOrdersUser";
    }

    @RequestMapping(value = "/viewcompletedorders/{email}/{status}")
    public String viewcompletedorderlist(@PathVariable ("email")String email, @PathVariable("status") String status, Model model)
    {
        List<Order> customerorderlist=orderService.getOrderByEmailAndStatus(email,status);
        model.addAttribute("customerorderlist",customerorderlist);
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        UserDetails userDetails=(UserDetails)authentication.getPrincipal();
        model.addAttribute("useremail",userDetails);
        return "CompletedOrdersUser";
    }
}
