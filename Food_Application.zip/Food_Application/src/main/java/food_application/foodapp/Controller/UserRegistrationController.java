package food_application.foodapp.Controller;

import food_application.foodapp.Model.User;
import food_application.foodapp.Model.UserRegistrationDto;
import food_application.foodapp.Respository.UserRepository;
import food_application.foodapp.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController {

	private UserService userService;

	@Autowired
	private UserRepository userRepository;


	public UserRegistrationController(UserService userService) {
		super();
		this.userService = userService;
	}
	
	@ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto() {
        return new UserRegistrationDto();
    }
	
	@GetMapping
	public String showRegistrationForm() {
		return "registration";
	}
	
	@PostMapping
	public String registerUserAccount(@ModelAttribute("user") @Valid UserRegistrationDto registrationDto, BindingResult bindingResult)
	{
		if (CheckIfUserExists(registrationDto.getEmail()))
		{
			return "redirect:/registration?unsuccess1";
		}

		userService.save(registrationDto);
		return "redirect:/registration?success";
	}

	public boolean CheckIfUserExists(String email) {
		return userRepository.findByEmail(email) !=null ? true : false;
	}
}
