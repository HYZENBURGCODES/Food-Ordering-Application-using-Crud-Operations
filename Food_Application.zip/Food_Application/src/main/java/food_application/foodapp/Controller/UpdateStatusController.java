package food_application.foodapp.Controller;

import food_application.foodapp.Model.Order;
import food_application.foodapp.Respository.OrderRepository;
import food_application.foodapp.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping(value = "/update",method = RequestMethod.PUT)
public class UpdateStatusController
{
    @Autowired
    OrderService orderService;

    @Autowired
    OrderRepository orderRepository;

    @PutMapping(value = "/adminstatus/{id}")
    public Order UpdateStatus(@PathVariable("id")Long id, @Valid @RequestBody Order order)
    {
        return orderService.UpdateStatus(id,order);
    }

}
