package food_application.foodapp.Controller;


import food_application.foodapp.Model.Food;
import food_application.foodapp.Service.FoodService;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/add")
public class AddFoodController
{
    private static Logger logger=LoggerFactory.getLogger(AddFoodController.class);
    public static String UploadDirectory=System.getProperty("user.dir")+"/uploads/";


    @Autowired
    FoodService foodService;

    @GetMapping
    public String add()
    {
        return "addfood";
    }
    @PostMapping
    public String createFood(@Valid Food food, @RequestParam("fname")final String name,
                             @RequestParam("description")final String desc, final @RequestParam("file") MultipartFile file,
                             @RequestParam("price")final int price)
    {
        try
        {
            if(food==null)
            {
                return "redirect:/add?unsuccess";
            }
            String filename=file.getOriginalFilename();
            String filepath=Paths.get(UploadDirectory,filename).toString();
            LocalDateTime localDateTime=LocalDateTime.now();
            DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
            String created_date=formatter.format(localDateTime);

            BufferedOutputStream stream=new BufferedOutputStream(new FileOutputStream(new File(filepath)));
            stream.write(file.getBytes());
            stream.close();

            byte[] imagedata=file.getBytes();
            String base64EncodedImage = Base64.encodeBase64String(imagedata);

            food.setName(name);
            food.setPrice(price);
            food.setDesignation(desc);
            food.setFileName(filename);
            food.setImage(base64EncodedImage.getBytes(StandardCharsets.UTF_8));
            food.setFilePath(filepath);
            food.setCreatedDate(created_date);

            boolean status=foodService.saveFood(food);
            if(status)
            {
                return "redirect:/add?success";
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
            logger.info("Exception :"+e);
        }
        return "redirect:/add?unsuccess";
    }
}
