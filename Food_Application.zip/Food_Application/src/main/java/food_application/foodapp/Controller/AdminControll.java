package food_application.foodapp.Controller;


import food_application.foodapp.Model.Contact;
import food_application.foodapp.Model.Food;
import food_application.foodapp.Model.Order;
import food_application.foodapp.Respository.OrderRepository;
import food_application.foodapp.Service.ContactService;
import food_application.foodapp.Service.FoodService;
import food_application.foodapp.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminControll
{
    @Autowired
    FoodService foodService;

    @Autowired
    OrderService orderService;

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    ContactService contactService;

    @GetMapping
    public String home()
    {
        return "home";
    }

    @GetMapping(value = "/viewfoodlist")
    public String viewallfoods(Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("viewfoodlistadmin");
        List<Food> foodList=foodService.getAllFoods();
        model.addAttribute("adminfoodlist",foodList);
        return "viewfoodlistadmin";
    }

    @GetMapping(value = "/deletefood/{id}")
    public String deletefood(@PathVariable("id") Long id)
    {
        foodService.deleteFile(id);
        return  "redirect:/admin/viewfoodlist";
    }

    @GetMapping(value = "/viewneworders/{status}")
    public String viewnewordersadmin(@PathVariable("status") String status, Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("NewOrdersAdmin");
        List<Order> orderList=orderService.getOrderByStatus(status);
        model.addAttribute("orderlist",orderList);
        return "NewOrdersAdmin";
    }

    @GetMapping(value = "/update/{id}")
    public String UpdateStatus(@PathVariable("id") Long id,Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("OrderDetailsAdmin");
        Optional<Order> orderdetails=orderService.getOrderByID(id);
        model.addAttribute("id",orderdetails.get().getOrder_id());
        model.addAttribute("address",orderdetails.get().getAddress());
        model.addAttribute("city",orderdetails.get().getCity());
        model.addAttribute("contact",orderdetails.get().getContact());
        model.addAttribute("email",orderdetails.get().getEmail());
        model.addAttribute("firstname",orderdetails.get().getFirstname());
        model.addAttribute("foodname",orderdetails.get().getFoodname());
        model.addAttribute("lastname",orderdetails.get().getLastname());
        model.addAttribute("price",orderdetails.get().getPrice());
        model.addAttribute("quantity",orderdetails.get().getQnty());
        model.addAttribute("status",orderdetails.get().getStatus());
        model.addAttribute("total",orderdetails.get().getTotal());
        model.addAttribute("date",orderdetails.get().getDate());
        return "OrderDetailsAdmin";
    }

    @GetMapping(value = "/viewcontacts")
    public String ViewContactAdmin(Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("ViewMessageAdmin");
        List<Contact> contactList=contactService.getAllMessages();
        model.addAttribute("msgelist",contactList);
        return "ViewMessageAdmin";
    }

    @PostMapping(value = "/updateorder")
    public String Update_Order(@Valid Order order, @RequestParam("order_id")Long id,@RequestParam("firstname")String firstname, @RequestParam("lastname") String lastname,
                             @RequestParam("address") String address, @RequestParam("city") String city,
                             @RequestParam("contact") String contact, @RequestParam("price")int price, @RequestParam("qnty")int qty,
                             @RequestParam("foodname") String foodname,@RequestParam("email")String email,@RequestParam("updatestatus")String status,@RequestParam("total")int total,
                               @RequestParam("date")String date)
    {
        try
        {
            order.setOrder_id(id);
            order.setFirstname(firstname);
            order.setLastname(lastname);
            order.setAddress(address);
            order.setCity(city);
            order.setContact(contact);
            order.setStatus(status);
            order.setPrice(price);
            order.setQnty(qty);
            order.setTotal(total);
            order.setFoodname(foodname);
            order.setDate(date);
            order.setEmail(email);

            orderService.saveOrder(order);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "NewOrdersAdmin";
    }

    @GetMapping(value = "/onthewayorders/{status}")
    public String viewonthewayordersadmin(@PathVariable("status") String status, Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("OnTheWayOrdersAdmin");
        List<Order> orderList=orderService.getOrderByStatus(status);
        model.addAttribute("orderlist",orderList);
        return "OnTheWayOrdersAdmin";
    }

    @GetMapping(value = "/completedorders/{status}")
    public String completedordersadmin(@PathVariable("status") String status, Model model)
    {
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.setViewName("CompletedOrdersAdmin");
        List<Order> orderList=orderService.getOrderByStatus(status);
        model.addAttribute("orderlist",orderList);
        return "CompletedOrdersAdmin";
    }



}
