package food_application.foodapp.AndroidAPI;

import food_application.foodapp.Model.UserRegistrationDto;
import food_application.foodapp.Model.*;
import food_application.foodapp.Respository.FoodRepository;
import food_application.foodapp.Respository.OrderRepository;
import food_application.foodapp.Respository.ReviewRepository;
import food_application.foodapp.Respository.UserRepository;
import food_application.foodapp.Service.*;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;


@RestController
@RequestMapping("/api/v1/")
public class API
{
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private FoodRepository foodRepository;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    @Autowired
    private ContactService contactService;

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private ReviewRepository reviewRepository;

    @PostMapping("User/Register")
    public JSONObject user_register(@RequestBody UserRegistrationDto userRegistrationDto){
        JSONObject jsonObject=new JSONObject();
        userService.save(userRegistrationDto);

        jsonObject.put("Response","User Saved");
        return jsonObject;
    }

    @GetMapping("login/{username}/{password}")
    public JSONObject loginResponse(@PathVariable(value = "username")String username, @PathVariable(value = "password")String password){
        JSONObject obj = new JSONObject();
        User currentUser = userRepository.findByEmail(username);
        if(currentUser !=null){
            if(userService.passwordCheck(password, currentUser.getPassword())){
                obj.put("Response", "Correct");
            }else {
                obj.put("Response", "Password Incorrect");
            }
        }
        else {
            obj.put("Response", "User does not exist");
        }
        return obj;
    }

    @GetMapping ( "User/foodlist")
    public List<Food> getAllFoods()
    {
        return foodRepository.findAll();
    }

    @GetMapping("User/vieworders/{email}/{status}")
    public List<Order> getCustomerOrders(@PathVariable(value = "email")String username,@PathVariable(value = "status")String status)
    {
        return orderRepository.findByEmailAndStatus(username,status);
    }
    @GetMapping("User/userdetails/{email}")
    public List<User> getUserDetails(@PathVariable(value = "email") String email)
    {
        return userRepository.findDetailsByEmail(email);
    }

    @PostMapping("User/addcontact")
    public JSONObject user_contact(@RequestBody Contact contact) throws IOException {
        JSONObject jsonObject=new JSONObject();
        contactService.AddReviews(contact);
        jsonObject.put("Response","Message Sent");
        return jsonObject;
    }

    @PostMapping("User/addreviews")
    public JSONObject user_add_review(@RequestBody Reviews reviews) throws IOException {
        JSONObject jsonObject=new JSONObject();
        reviewService.AddReviews(reviews);
        jsonObject.put("Response","Review Added");
        return jsonObject;
    }
    @GetMapping ( value = "User/reviewlist")
    public List<Reviews> getAllReviews()
    {
        return reviewRepository.findAll();
    }

    @PostMapping("User/placeorder")
    public JSONObject user_place_order(@RequestBody Order order) throws IOException {
        JSONObject jsonObject=new JSONObject();
        orderService.saveOrder(order);
        jsonObject.put("Response","Order Added");
        return jsonObject;
    }
    @GetMapping("User/onthewayorders/{email}/{status}")
    public List<Order> getOnTheWayCustomerOrders(@PathVariable(value = "email")String username,@PathVariable(value = "status")String status)
    {
        return orderRepository.findByEmailAndStatus(username,status);
    }
    @GetMapping("User/completedorders/{email}/{status}")
    public List<Order> getCompletedCustomerOrders(@PathVariable(value = "email")String username,@PathVariable(value = "status")String status)
    {
        return orderRepository.findByEmailAndStatus(username,status);
    }
    @PostMapping("User/update")
    public JSONObject update_order(@RequestBody Order order) throws IOException {
        JSONObject jsonObject=new JSONObject();
        orderService.saveOrder(order);
        jsonObject.put("Response","Updated");
        return jsonObject;
    }



}
