package food_application.foodapp.Respository;

import food_application.foodapp.Model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order,Long>
{
    List<Order> findByEmail(String email);

    List<Order> findByStatus(String status);

    List<Order> findByEmailAndStatus(String email,String status);


}
