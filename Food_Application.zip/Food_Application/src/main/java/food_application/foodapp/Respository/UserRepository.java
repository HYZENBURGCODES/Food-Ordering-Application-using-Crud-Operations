package food_application.foodapp.Respository;


import food_application.foodapp.Model.Order;
import food_application.foodapp.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{
	User findByEmail(String email);

	List<User> findDetailsByEmail(String email);

}
