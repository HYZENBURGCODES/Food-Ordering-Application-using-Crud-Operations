package food_application.foodapp.Service;

import food_application.foodapp.Model.Reviews;

import java.io.IOException;
import java.util.List;

public interface ReviewService
{
    boolean AddReviews(Reviews reviews) throws IOException;

    List<Reviews> getAllReviews();

}
