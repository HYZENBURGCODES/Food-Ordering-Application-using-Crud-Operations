package food_application.foodapp.Service;

import food_application.foodapp.Model.Contact;
import food_application.foodapp.Model.Order;
import food_application.foodapp.Model.Reviews;

import java.io.IOException;
import java.util.List;

public interface ContactService
{
    boolean AddReviews(Contact contact) throws IOException;

    List<Contact> getAllMessages();
}
