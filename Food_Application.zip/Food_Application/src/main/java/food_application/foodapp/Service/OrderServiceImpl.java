package food_application.foodapp.Service;

import food_application.foodapp.Model.Order;
import food_application.foodapp.Respository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService
{
    @Autowired
    private OrderRepository orderRepository;

    @Override
    public String saveOrder(Order order)
    {
        if(order!=null)
        {
            orderRepository.save(order);
        }
        else
        {
            return "Error";
        }
        return "Error";
    }

    @Override
    public Optional<Order> getOrderByID(Long id) {
        return orderRepository.findById(id);
    }

    @Override
    public List<Order> getOrderByStatus(String status)
    {
        return orderRepository.findByStatus(status);
    }

    @Override
    public List<Order> getOrderByEmailAndStatus(String email, String status) {
        return orderRepository.findByEmailAndStatus(email,status);
    }

}
