package food_application.foodapp.Service;

import food_application.foodapp.Model.Contact;
import food_application.foodapp.Respository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.List;

@Service
@Transactional
public class ContactImpl implements ContactService
{
    @Autowired
    ContactRepository contactRepository;

    @Override
    public boolean AddReviews(Contact contact) throws IOException
    {
        try
        {
            if(contact!=null)
            {
                contactRepository.save(contact);
                return true;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public List<Contact> getAllMessages()
    {
        return contactRepository.findAll();
    }
}
