package food_application.foodapp.Service;

import food_application.foodapp.Model.Food;
import food_application.foodapp.Respository.FoodRepository;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public interface FoodService
{
    boolean saveFood(Food food) throws IOException;

    List<Food> getAllFoods();

    Optional<Food> getFoodByID(Long id);

    void deleteFile(Long id);
}
