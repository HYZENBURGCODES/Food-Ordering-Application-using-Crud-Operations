package food_application.foodapp.Service;

import food_application.foodapp.Model.Order;

import java.util.List;
import java.util.Optional;

public interface OrderService
{
    String saveOrder(Order order);

//    List<Order> getAllOrders();
//
//    List<Order> getOrderByEmail (String email);

    Optional<Order> getOrderByID(Long id);

    List<Order> getOrderByStatus(String status);

    List<Order> getOrderByEmailAndStatus(String email,String status);
}
