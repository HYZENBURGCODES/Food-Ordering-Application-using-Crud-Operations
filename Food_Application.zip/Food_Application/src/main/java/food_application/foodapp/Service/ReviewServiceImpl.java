package food_application.foodapp.Service;

import food_application.foodapp.Model.Reviews;
import food_application.foodapp.Respository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ReviewServiceImpl implements ReviewService
{
    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public boolean AddReviews(Reviews reviews)
    {
        try
        {
            if(reviews!=null)
            {
                reviewRepository.save(reviews);
                return true;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }
        return false;

    }

    @Override
    public List<Reviews> getAllReviews() {
        return reviewRepository.findAll();
    }
}
