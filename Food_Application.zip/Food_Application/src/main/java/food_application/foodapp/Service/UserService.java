package food_application.foodapp.Service;

import food_application.foodapp.Model.UserRegistrationDto;
import food_application.foodapp.Model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService{
    User getUserByEmail(String email);

    User save(UserRegistrationDto registrationDto);

    boolean passwordCheck(String password, String password1);

    boolean CheckIfUserExists(String email);
}
