package food_application.foodapp;

import food_application.foodapp.Model.Food;
import food_application.foodapp.Model.Order;
import food_application.foodapp.Model.User;
import food_application.foodapp.Respository.FoodRepository;
import food_application.foodapp.Respository.OrderRepository;
import food_application.foodapp.Respository.UserRepository;
import food_application.foodapp.Service.FoodService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Every.everyItem;

import static org.junit.Assert.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import java.util.List;

@SpringBootTest
@AutoConfigureMockMvc
class FoodappApplicationTests
{
    @Autowired
    FoodRepository foodRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    OrderRepository orderRepository;

    @MockBean
    FoodService foodService;

    @Autowired
    private MockMvc mockMvc;

    //saving food items to DB
    @Test
    @DisplayName("Food Adding Test Success")
    public void TestAddFood()
    {
        LocalDateTime localDateTime=LocalDateTime.now();
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String created_date=formatter.format(localDateTime);

        Food food=new Food();
        food.setName("example 1");
        food.setPrice(200);
        food.setDesignation("example 1");
        food.setFilePath("//");
        food.setFileName("example 1");
        food.setCreatedDate(created_date);
        foodRepository.save(food);
    }

    //getting all the food items
    @Test
    @DisplayName("All Foods")
    public void TestGetAllFoods()
    {
        //checking food list is greater than 20...
        //food list=8
        List<Food> foodList=foodRepository.findAll();
        assertThat(foodList.size(),greaterThan(0));
    }

    //Getting Foods Items by ID
    @Test
    public void FindFoodByID()
    {
        Long id=14L;
        Optional<Food> food= foodRepository.findById(id);

        //expecting the 200 will be equal to the price of founded Food Item
        assertEquals(200,food.get().getPrice());
    }

    //Get USer Details using User Email
    @Test
    @DisplayName("User Details")
    public void FindUserDetailsByEmail()
    {
        String email="warriorashif98@gmail.com";
        List<User> userDetailsList=userRepository.findDetailsByEmail(email);
    }

    //Get Order Details By Customer Email
    @Test
    @DisplayName("Order Details By Email")
    public void GetOrderDetailsByID()
    {
        String email="warriorashif98@gmail.com";
        List<Order> orderList= orderRepository.findByEmail(email);
    }

    //Get On the way Order details By Order Status
    @Test
    @DisplayName("Order Details By Status")
    public void GetOrderDetailsByStatus()
    {
        String Status="On the way";
        List<Order> orderList=orderRepository.findByStatus(Status);
    }

    //Get Preparing Order details By Order Status
    @Test
    @DisplayName("Order Details By Status")
    public void GetPreparingOrderDetailsByStatus()
    {
        String test="Preparing";
        String test1="On the way";

        List<Order> orderList=orderRepository.findByStatus(test);

        //status of the founded order should be equal to "preparing"
        assertEquals(test,orderList.get(0).getStatus());

        //status of the founded order should be equal to "preparing".But for testing purpose,we're expecting the expected result as On the way.system will display error Message.
        //assertEquals(test1,orderList.get(0).getStatus());
    }

    //Delete Food Items from DB
    @Test
    @DisplayName("Food Deleted")
    public void DeleteFoodByID()
    {
        //food item will be deleted from Database
        Long food_ID=25L;
        foodService.deleteFile(food_ID);
    }

    //Get All the Reviews using the rest API
    @Test
    @DisplayName("GET/api/v1/User/foodlist")
    public void getFoodList() throws Exception
    {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/User/foodlist"))
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

    //get all the reviews list using Rest API
    @Test
    @DisplayName("GET/api/v1/User/reviewlist")
    public void GetReviewList() throws Exception
    {
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/User/reviewlist"))
                .andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON));
    }

    //check login using valid vredentials
    @Test
    @DisplayName("GET/api/v1/login/{email}/{password}")
    public void CustomerLoginTest() throws Exception
    {
        //Expecting a valid user as Not found
        //System found the User and display Error
        String email="warriorashif98@gmail.com";
        String Password="0714842136";

        //expected 404 //actual 200
        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/login/"+email+"/"+Password))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }



    
}
