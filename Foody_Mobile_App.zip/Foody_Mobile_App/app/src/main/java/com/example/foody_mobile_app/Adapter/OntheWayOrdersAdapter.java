package com.example.foody_mobile_app.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foody_mobile_app.CustomerCheckoutActivity;
import com.example.foody_mobile_app.Model.Order;
import com.example.foody_mobile_app.OntheWayOrdersActivity;
import com.example.foody_mobile_app.R;
import com.example.foody_mobile_app.UpdateOrderActivity;

import java.util.ArrayList;

public class OntheWayOrdersAdapter extends RecyclerView.Adapter<OntheWayOrdersAdapter.ViewHolder>
{
    private ArrayList<Order> orderArrayList=new ArrayList<>();
    private Context context;

    public OntheWayOrdersAdapter(ArrayList<Order> orderArrayList, Context context) {
        this.orderArrayList = orderArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public OntheWayOrdersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        view=layoutInflater.inflate(R.layout.customer_ontheway_orders_list,parent,false);
        OntheWayOrdersAdapter.ViewHolder viewHolder=new OntheWayOrdersAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull OntheWayOrdersAdapter.ViewHolder holder, final int position)
    {
        final String string_order_id=String.valueOf(orderArrayList.get(position).getOrder_id());
        final String string_qunatity=String.valueOf(orderArrayList.get(position).getQnty());
        final String string_total=String.valueOf(orderArrayList.get(position).getTotal());
        final String item_price=String.valueOf(orderArrayList.get(position).getPrice());
        final String email_customer= orderArrayList.get(position).getEmail();
        final String fname_customer= orderArrayList.get(position).getFirstname();
        final String lname_customer= orderArrayList.get(position).getLastname();
        final String city= orderArrayList.get(position).getCity();
        final String contact= orderArrayList.get(position).getContact();



        holder.order_id_View.setText(string_order_id);
        holder.address_view.setText(orderArrayList.get(position).getAddress());
        holder.date_view.setText(orderArrayList.get(position).getDate());
        holder.food_name_view.setText(orderArrayList.get(position).getFoodname());
        holder.qnty_viewview.setText(string_qunatity);
        holder.status_view.setText(orderArrayList.get(position).getStatus());
        holder.total_view.setText(string_total);

        holder.update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(context, UpdateOrderActivity.class);
                intent.putExtra("foodname",orderArrayList.get(position).getFoodname());
                intent.putExtra("foodprice",orderArrayList.get(position).getPrice());
                intent.putExtra("total",orderArrayList.get(position).getTotal());
                intent.putExtra("qnty",orderArrayList.get(position).getQnty());
                intent.putExtra("email",orderArrayList.get(position).getEmail());
                intent.putExtra("fname",orderArrayList.get(position).getFirstname());
                intent.putExtra("lname",orderArrayList.get(position).getLastname());
                intent.putExtra("city",orderArrayList.get(position).getCity());
                intent.putExtra("address",orderArrayList.get(position).getAddress());
                intent.putExtra("contact",orderArrayList.get(position).getContact());
                intent.putExtra("id",orderArrayList.get(position).getOrder_id());
                intent.putExtra("status",orderArrayList.get(position).getStatus());
                intent.putExtra("date",orderArrayList.get(position).getDate());
                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return orderArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView order_id_View;
        private TextView food_name_view;
        private TextView date_view;
        private TextView qnty_viewview;
        private TextView total_view;
        private TextView status_view;
        private TextView address_view;
        private Button update_button;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            order_id_View=itemView.findViewById(R.id.new_order_id_onthe_way);
            food_name_view=itemView.findViewById(R.id.food_name_order_ontheway);
            date_view=itemView.findViewById(R.id.date_order_onthe_way);
            qnty_viewview=itemView.findViewById(R.id.food_qnty_order_onthe_way);
            total_view=itemView.findViewById(R.id.food_total_order_onthe_way);
            status_view=itemView.findViewById(R.id.food_status_order_onthe_way);
            address_view=itemView.findViewById(R.id.food_dev_address_order_onthe_way);
            update_button=itemView.findViewById(R.id.update_order_button_onthe_way);
        }
    }
}
