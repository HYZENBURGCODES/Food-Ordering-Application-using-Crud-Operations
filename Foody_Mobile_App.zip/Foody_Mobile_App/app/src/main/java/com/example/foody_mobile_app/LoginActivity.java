package com.example.foody_mobile_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.ResponseJson.LoginResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity
{
    private EditText email_et,password_et;
    private Button login_bt,register_bt;
    private Foody_API foody_api;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        email_et=(EditText)findViewById(R.id.login_email);
        password_et=(EditText)findViewById(R.id.login_password);

        login_bt=(Button)findViewById(R.id.login_button);
        login_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(email_et.getText().toString().isEmpty())
                {
                    Toast.makeText(LoginActivity.this, "No Email Detected", Toast.LENGTH_SHORT).show();
                }
                else if(password_et.getText().toString().isEmpty())
                {
                    Toast.makeText(LoginActivity.this, "No Password Detected", Toast.LENGTH_SHORT).show();
                }
                else {
                    Login();
                }
            }
        });
        register_bt=(Button)findViewById(R.id.register_button_login);
        register_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private void Login()
    {
        foody_api=API_Client.getRetrofit().create(Foody_API.class);

        final String email=email_et.getText().toString();
        String password=password_et.getText().toString();

        Call<LoginResponse> loginResponseCall=foody_api.getLoginResponse(email,password);
        loginResponseCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response)
            {
                LoginResponse loginResponse=response.body();
                if(loginResponse.getResponse().matches("Correct"))
                {
                    LoggedInCache.loggedInUser=new LoggedInUser(email,"");
                    Toast.makeText(LoginActivity.this, "login success", Toast.LENGTH_SHORT).show();
                    Intent myIntent = new Intent(LoginActivity.this, CustomerHomeActivity.class);
                    myIntent.putExtra("email",email);
                    LoginActivity.this.startActivity(myIntent);
                }
                else if (loginResponse.getResponse().matches("Password Incorrect"))
                {
                    Toast.makeText(LoginActivity.this, "Password Incorrect", Toast.LENGTH_SHORT).show();
                }
                else if(loginResponse.getResponse().matches("User does not exist"))
                {
                    Toast.makeText(LoginActivity.this, "User Does not exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t)
            {
                Toast.makeText(LoginActivity.this, "Login Error: "+t, Toast.LENGTH_SHORT).show();

            }
        });
   }
}
