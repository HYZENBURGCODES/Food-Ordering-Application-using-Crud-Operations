package com.example.foody_mobile_app.Model;

import java.io.Serializable;

public class OrderDto implements Serializable
{
    private String firstname;

    private String lastname;

    private String email;

    private String foodname;

    private int price;

    private int quantity;

    private int total;

    private String address;

    private String city;

    private String contact;

    private String status;

    private String date;

    public OrderDto()
    {

    }

//    public OrderDto(String firstname, String lastname, String email, String foodname, int price, int quantity, int total, String address, String city, String contact, String status, String date) {
//        this.firstname = firstname;
//        this.lastname = lastname;
//        this.email = email;
//        this.foodname = foodname;
//        this.price = price;
//        this.quantity = quantity;
//        this.total = total;
//        this.address = address;
//        this.city = city;
//        this.contact = contact;
//        this.status = status;
//        this.date = date;
//    }

    public OrderDto(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
