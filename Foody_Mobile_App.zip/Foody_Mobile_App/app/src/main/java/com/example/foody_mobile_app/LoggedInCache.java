package com.example.foody_mobile_app;

public class LoggedInCache
{
    public static LoggedInUser loggedInUser;
}
