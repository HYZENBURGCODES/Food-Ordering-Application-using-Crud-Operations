package com.example.foody_mobile_app.Model;

import java.io.Serializable;

public class ContactDto implements Serializable
{
    private String email;
    private String message;
    private String date;

    public ContactDto(String email, String message, String date) {
        this.email = email;
        this.message = message;
        this.date = date;
    }

    public ContactDto() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
