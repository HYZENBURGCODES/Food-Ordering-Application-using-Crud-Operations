package com.example.foody_mobile_app.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Review
{
    @SerializedName("reviews_ID")
    @Expose
    private String id;

    @SerializedName("review")
    @Expose
    private String reviews;

    @SerializedName("date_and_time")
    @Expose
    private String date;

    @SerializedName("email")
    @Expose
    private String email;

    public Review(String id, String reviews, String date, String email) {
        this.id = id;
        this.reviews = reviews;
        this.date = date;
        this.email = email;
    }

    public Review() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReviews() {
        return reviews;
    }

    public void setReviews(String reviews) {
        this.reviews = reviews;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
