package com.example.foody_mobile_app.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Order
{
    private String order_id;

    private String firstname;

    private String lastname;

    private String email;

    private String foodname;

    private int price;

    @SerializedName("quantity")
    @Expose
    private int qnty;

    private int total;

    private String address;

    private String city;

    private String contact;

    private String status;

    private String date;

    public Order()
    {

    }

    public Order(String order_id, String firstname, String lastname, String email, String foodname, int price, int qnty, int total, String address, String city, String contact, String status, String date) {
        this.order_id = order_id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.foodname = foodname;
        this.price = price;
        this.qnty = qnty;
        this.total = total;
        this.address = address;
        this.city = city;
        this.contact = contact;
        this.status = status;
        this.date = date;
    }

    public Order(String order_id, String foodname, int qnty, int total, String address, String status, String date) {
        this.order_id = order_id;
        this.foodname = foodname;
        this.qnty = qnty;
        this.total = total;
        this.address = address;
        this.status = status;
        this.date = date;
    }

    public Order(String email) {
        this.email = email;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQnty() {
        return qnty;
    }

    public void setQnty(int qnty) {
        this.qnty = qnty;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
