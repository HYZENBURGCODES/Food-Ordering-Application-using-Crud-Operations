package com.example.foody_mobile_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Adapter.CompletedOrdersAdapter;
import com.example.foody_mobile_app.Adapter.OntheWayOrdersAdapter;
import com.example.foody_mobile_app.Model.Order;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerOrderHistoryActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private Foody_API foody_api;
    ArrayList<Order> orderArrayList=new ArrayList<>();
    private RecyclerView orderhistoryrecyclerview;
    private CompletedOrdersAdapter completedOrdersAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_order_history);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);

        orderhistoryrecyclerview=findViewById(R.id.customer_completed_orders_view);
        orderhistoryrecyclerview.setLayoutManager(new LinearLayoutManager(this));

        Intent intent=getIntent();
        String email=intent.getStringExtra("email");
        String status= "Delivered";

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_order_history);
        txtProfileName.setText(email);

        foody_api= API_Client.getRetrofit().create(Foody_API.class);
        Call<List<Order>> call=foody_api.ViewCompletedOrders(email,status);
        call.enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response)
            {
                if(response.isSuccessful())
                {
                    String message="successful";
                    Toast.makeText(CustomerOrderHistoryActivity.this,message,Toast.LENGTH_SHORT).show();
                    orderArrayList= new ArrayList<>(response.body());
                    completedOrdersAdapter=new CompletedOrdersAdapter(orderArrayList,CustomerOrderHistoryActivity.this);
                    orderhistoryrecyclerview.setAdapter(completedOrdersAdapter);
                }
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t)
            {
                Toast.makeText(CustomerOrderHistoryActivity.this,"Order List Failed",Toast.LENGTH_SHORT).show();

            }
        });

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.customer_order_history, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));;
                break;
            case R.id.navigation_orders:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerViewOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerOrderHistoryActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
