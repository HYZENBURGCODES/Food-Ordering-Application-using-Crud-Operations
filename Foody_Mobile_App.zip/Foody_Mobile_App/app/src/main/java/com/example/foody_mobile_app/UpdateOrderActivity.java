package com.example.foody_mobile_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.Order;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateOrderActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private Foody_API foody_api;
    private Button update_button,Home_button;
    private ImageView updatedimageview;
    private TextView updatedtextview,reachedtextview;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_order);

        Intent get_order_details= getIntent();
        final String food_name=get_order_details.getStringExtra("foodname");
        final int food_price=get_order_details.getIntExtra("foodprice",0);
        final String city=get_order_details.getStringExtra("city");
        final String address=get_order_details.getStringExtra("address");
        final String contact=get_order_details.getStringExtra("contact");
        final int qnty=get_order_details.getIntExtra("qnty",0);
        final String order_id=get_order_details.getStringExtra("id");
        final String fname=get_order_details.getStringExtra("fname");
        final String lname=get_order_details.getStringExtra("lname");
        final String email=get_order_details.getStringExtra("email");
        final int total=get_order_details.getIntExtra("total",0);
        final String date=get_order_details.getStringExtra("date");

        updatedimageview=findViewById(R.id.correct_image_view);
        updatedtextview=findViewById(R.id.updated_text_view);
        reachedtextview=findViewById(R.id.reachedtextview);
        update_button=findViewById(R.id.update_order_button);

        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view)
            {
                Order order=new Order();
                order.setDate(date);
                order.setCity(city);
                order.setAddress(address);
                order.setFoodname(food_name);
                order.setLastname(lname);
                order.setEmail(email);
                order.setContact(contact);
                order.setQnty(qnty);
                order.setTotal(total);
                order.setOrder_id(order_id);
                order.setFirstname(fname);
                order.setPrice(food_price);
                String status="Delivered";
                order.setStatus(status);
                foody_api= API_Client.getRetrofit().create(Foody_API.class);
                Call<Void> call =foody_api.update_Order(order);
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        Toast.makeText(UpdateOrderActivity.this, "Success", Toast.LENGTH_SHORT).show();
                        updatedimageview.setImageResource(R.drawable.correctlogo);
                        updatedtextview.setText("Enjoy your Meal !");
                        update_button.setVisibility(View.GONE);
                        reachedtextview.setText("Thank you for Choosing Foody!");

                    }
                    @Override
                    public void onFailure(Call<Void> call, Throwable t)
                    {
                        Toast.makeText(UpdateOrderActivity.this, "Something went Wrong", Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        Home_button=findViewById(R.id.update_order_home_button);
        Home_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,CustomerHomeActivity.class);
                intent.putExtra("email",email);
                context.startActivity(intent);
            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_update_order);
        txtProfileName.setText(email);

        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.update_order, menu);
        return true;
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(UpdateOrderActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));;
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(UpdateOrderActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(UpdateOrderActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(UpdateOrderActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(UpdateOrderActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(UpdateOrderActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(UpdateOrderActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
