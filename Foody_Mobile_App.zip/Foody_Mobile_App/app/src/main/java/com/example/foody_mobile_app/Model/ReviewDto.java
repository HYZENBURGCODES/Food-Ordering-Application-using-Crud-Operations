package com.example.foody_mobile_app.Model;

import java.io.Serializable;

public class ReviewDto implements Serializable
{
    private String email;
    private String review;
    private String date_and_time;

    public ReviewDto(String email, String review, String date_and_time) {
        this.email = email;
        this.review = review;
        this.date_and_time = date_and_time;
    }

    public ReviewDto() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getDate_and_time() {
        return date_and_time;
    }

    public void setDate_and_time(String date_and_time) {
        this.date_and_time = date_and_time;
    }
}
