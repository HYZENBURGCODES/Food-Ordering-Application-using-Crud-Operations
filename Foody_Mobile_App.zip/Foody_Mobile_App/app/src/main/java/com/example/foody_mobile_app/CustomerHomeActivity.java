package com.example.foody_mobile_app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.Food;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.jakewharton.picasso.OkHttp3Downloader;
import com.squareup.picasso.OkHttpDownloader;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerHomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{
    private Foody_API foody_api;
    private List<Food> foodArrayList=new ArrayList<>();
    GridView gridView;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_home);

        gridView=findViewById(R.id.customer_menu_gridview);
        getFoodList();

        Intent receive_email= getIntent();
        String email=receive_email.getStringExtra("email");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_cus_home);
        txtProfileName.setText(email);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }
    private void getFoodList()
    {
        foody_api= API_Client.getRetrofit().create(Foody_API.class);
        Call<List<Food>> call=foody_api.getAllFoods();
        call.enqueue(new Callback<List<Food>>() {
            @Override
            public void onResponse(Call<List<Food>> call, Response<List<Food>> response)
            {
                if(response.isSuccessful())
                {
                    String message="successful";
                    Toast.makeText(CustomerHomeActivity.this,message,Toast.LENGTH_SHORT).show();
                    foodArrayList=response.body();
                    CustomerHomeActivity.FoodViewAdapter foodViewAdapter=new CustomerHomeActivity.FoodViewAdapter(foodArrayList,CustomerHomeActivity.this);
                    gridView.setAdapter(foodViewAdapter);
                }
            }

            @Override
            public void onFailure(Call<List<Food>> call, Throwable t)
            {
                Toast.makeText(CustomerHomeActivity.this,"Inquiry List Failed",Toast.LENGTH_SHORT).show();

            }
        });
    }
    public class FoodViewAdapter extends BaseAdapter
    {
        private List<Food> foodList;
        private Context context;
        private LayoutInflater layoutInflater;

        public FoodViewAdapter(List<Food> foodList, Context context) {
            this.foodList = foodList;
            this.context = context;
            this.layoutInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return foodList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            if(view==null)
            {
                view=layoutInflater.inflate(R.layout.list_item,viewGroup,false);

            }
            final TextView textView=view.findViewById(R.id.food_name);
            final TextView priceview=view.findViewById(R.id.food_price);
            final TextView desc=view.findViewById(R.id.desc_food);

            Intent receive_email= getIntent();
            final String email=receive_email.getStringExtra("email");

            textView.setText(foodList.get(i).getName());
            priceview.setText("Rs."+foodList.get(i).getPrice()+".00");
            final int price=foodList.get(i).getPrice();
            desc.setText(foodList.get(i).getDesc());

            Button buy_now_button=view.findViewById(R.id.buy_now_button);
            buy_now_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    Intent intent=new Intent(context,CustomerCheckoutActivity.class);
                    intent.putExtra("foodname",textView.getText().toString());
                    intent.putExtra("foodprice",priceview.getText().toString());
                    intent.putExtra("price",price);
                    intent.putExtra("desc",desc.getText().toString());
                    intent.putExtra("email",email);
                    context.startActivity(intent);


                }
            });
            return view;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.customer_home, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_orders:
                startActivity(new Intent(CustomerHomeActivity.this,CustomerViewOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerHomeActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerHomeActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerHomeActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerHomeActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerHomeActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerHomeActivity.this,LoginActivity.class));
                break;


        }
        return false;
    }
}
