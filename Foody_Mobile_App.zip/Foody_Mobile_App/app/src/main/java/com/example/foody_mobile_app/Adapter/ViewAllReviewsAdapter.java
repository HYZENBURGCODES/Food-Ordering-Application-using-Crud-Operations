package com.example.foody_mobile_app.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foody_mobile_app.Model.Review;
import com.example.foody_mobile_app.R;

import java.util.ArrayList;

public class ViewAllReviewsAdapter extends RecyclerView.Adapter<ViewAllReviewsAdapter.ViewHolder>
{
    private ArrayList<Review> reviewArrayList=new ArrayList<>();
    private Context context;

    public ViewAllReviewsAdapter(ArrayList<Review> reviewArrayList, Context context) {
        this.reviewArrayList = reviewArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view;
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        view=layoutInflater.inflate(R.layout.review_list,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewAllReviewsAdapter.ViewHolder holder, int position)
    {
        holder.review_view.setText(reviewArrayList.get(position).getReviews());
        holder.reviewer_view.setText(reviewArrayList.get(position).getEmail());
        holder.date_view.setText(reviewArrayList.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        return reviewArrayList.size();
    }

    public class ViewHolder  extends RecyclerView.ViewHolder
    {

        private TextView review_view;
        private TextView reviewer_view;
        private TextView date_view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            review_view=itemView.findViewById(R.id.view_review_text);
            reviewer_view=itemView.findViewById(R.id.view_reviewer_text);
            date_view=itemView.findViewById(R.id.view_review_date_text);
        }
    }
}
