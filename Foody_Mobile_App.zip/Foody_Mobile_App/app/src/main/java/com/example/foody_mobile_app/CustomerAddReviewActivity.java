package com.example.foody_mobile_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.ReviewDto;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerAddReviewActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private EditText Add_Reviews_edit_text;
    private Button Add_Review_Button;
    private Foody_API foody_api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_add_review);

        final Intent receive_email= getIntent();
        final String email=receive_email.getStringExtra("email");


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
        final String currentDateandTime = sdf.format(new Date());

        Add_Reviews_edit_text=findViewById(R.id.user_addreview_edit_text);
        Add_Review_Button=findViewById(R.id.addreview_submit_button);

        Add_Review_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                ReviewDto reviewDto=new ReviewDto();
                reviewDto.setEmail(email);
                reviewDto.setDate_and_time(currentDateandTime);
                reviewDto.setReview(Add_Reviews_edit_text.getText().toString());

                foody_api= API_Client.getRetrofit().create(Foody_API.class);
                Call<Void> call =foody_api.AddReview(reviewDto);
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        Toast.makeText(CustomerAddReviewActivity.this, "Review Added", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t)
                    {
                        Toast.makeText(CustomerAddReviewActivity.this, "Something went Wrong", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);

       TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_cus_add_review);
       txtProfileName.setText(email);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.customer_add_review, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));;
                break;
            case R.id.navigation_orders:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerViewOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerAddReviewActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerAddReviewActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerAddReviewActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
