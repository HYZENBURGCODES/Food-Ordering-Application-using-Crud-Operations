package com.example.foody_mobile_app;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.Order;
import com.example.foody_mobile_app.Model.OrderDto;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerCheckoutActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    AlertDialog.Builder builder;
    private EditText fname,lname,city,qnty,mobile,address,cardname,cardnum,doe,cvv;
    private Button place_order_button;
    private Foody_API foody_api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_checkout);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);

        Intent receive_email= getIntent();
        final String email=receive_email.getStringExtra("email");

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_checkout);
        txtProfileName.setText(email);

        Intent get_foodd_details= getIntent();
        final String food_name=get_foodd_details.getStringExtra("foodname");
        final String food_price=get_foodd_details.getStringExtra("foodprice");
        String food_desc=get_foodd_details.getStringExtra("desc");
        final int price=get_foodd_details.getIntExtra("price",0);

        TextView foodname_view=(TextView)findViewById(R.id.food_name_checkout);
        TextView fooddesc_view=(TextView)findViewById(R.id.food_desc_checkout);
        TextView foodprice_view=(TextView)findViewById(R.id.food_price_checkout);
        foodname_view.setText(food_name);
        fooddesc_view.setText(food_desc);
        foodprice_view.setText(food_price);

        place_order_button=(Button)findViewById(R.id.place_order_btn);
        fname=(EditText)findViewById(R.id.user_fname_edit_text);
        lname=(EditText)findViewById(R.id.user_lname_edit_text);
        city=(EditText)findViewById(R.id.user_city_edit_text);
        address=(EditText)findViewById(R.id.user_address_edit_text);
        mobile=(EditText)findViewById(R.id.user_mobile_edit_text);
        qnty=(EditText)findViewById(R.id.user_qnty_edit_text);
        cardname=(EditText)findViewById(R.id.user_cardname_edit_text);
        cardnum=(EditText)findViewById(R.id.user_cardnumber_edit_text);
        doe=(EditText)findViewById(R.id.user_doe_edit_text);
        cvv=(EditText)findViewById(R.id.user_cvv_edit_text);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
        final String currentDateandTime = sdf.format(new Date());

        place_order_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(cardname.getText().toString().isEmpty() || cardnum.getText().toString().isEmpty() || doe.getText().toString().isEmpty() ||
                        cvv.getText().toString().isEmpty() || fname.getText().toString().isEmpty() || lname.getText().toString().isEmpty() ||
                city.getText().toString().isEmpty() || address.getText().toString().isEmpty() || mobile.getText().toString().isEmpty() || qnty.getText().toString().isEmpty())
                {
                    Toast.makeText(CustomerCheckoutActivity.this, "Empty Fields Detected", Toast.LENGTH_SHORT).show();
                }
                else if(cardnum.length()<16 || doe.length()<5 || cvv.length()<3)
                {
                    Toast.makeText(CustomerCheckoutActivity.this, "No Valid Card Details Detected", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    OrderDto order= new OrderDto();
                    order.setFirstname(fname.getText().toString());
                    order.setLastname(fname.getText().toString());
                    order.setEmail(email);
                    order.setFoodname(food_name);
                    order.setAddress(address.getText().toString());
                    order.setCity(city.getText().toString());
                    order.setDate(currentDateandTime);
                    order.setStatus("Preparing");
                    order.setContact(mobile.getText().toString());

                    final int food_qnty=Integer.parseInt(qnty.getText().toString());
                    order.setQuantity(food_qnty);

                    final int Total= (price*food_qnty)+100;
                    order.setTotal(Total);
                    order.setPrice(price);

                    foody_api= API_Client.getRetrofit().create(Foody_API.class);
                    Call<Void> call =foody_api.PlaceOrder(order);
                    call.enqueue(new Callback<Void>() {
                        @Override
                        public void onResponse(Call<Void> call, Response<Void> response)
                        {
                            Toast.makeText(CustomerCheckoutActivity.this, "Order Placed", Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent(CustomerCheckoutActivity.this,OrderReceiptActivity.class);
                            intent.putExtra("foodname",food_name);
                            intent.putExtra("qnty",food_qnty);
                            intent.putExtra("total",Total);
                            intent.putExtra("email",email);
                            intent.putExtra("address",address.getText().toString());
                            startActivity(intent);
                        }

                        @Override
                        public void onFailure(Call<Void> call, Throwable t)
                        {
                            Toast.makeText(CustomerCheckoutActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();

                        }
                    });
                }
            }
        });

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.customer_checkout, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));;
                break;
            case R.id.navigation_orders:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerViewOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerCheckoutActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerCheckoutActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerCheckoutActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
