package com.example.foody_mobile_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.UserRegistartionDto;
import com.example.foody_mobile_app.ResponseJson.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity
{
    private EditText fname,lname,email_,password_,contact_n;
    private Button signin_b,signup_b;
    private Foody_API foody_api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        fname=findViewById(R.id.firstname);
        lname=findViewById(R.id.lastname);
        email_=findViewById(R.id.email);
        password_=findViewById(R.id.password);
        contact_n=findViewById(R.id.mobile);

        signup_b=findViewById(R.id.signup_reg);
        signup_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(fname.getText().toString().equals("")|| lname.getText().toString().equals("")|| email_.getText().toString().equals("")
                || password_.getText().toString().equals("")|| contact_n.getText().toString().equals(""))
                {
                    Toast.makeText(RegisterActivity.this, "Empty Field Detected", Toast.LENGTH_SHORT).show();
                }
                else if (password_.length()<8)
                {
                    Toast.makeText(RegisterActivity.this, "Weak Password", Toast.LENGTH_SHORT).show();
                }
                else if (contact_n.length()<10 || contact_n.length()>10)
                {
                    Toast.makeText(RegisterActivity.this, "Invalid Contact Number", Toast.LENGTH_SHORT).show();
                }
                else {

                    UserRegistartionDto userRegistartionDto = new UserRegistartionDto();
                    userRegistartionDto.setFirstName(fname.getText().toString());
                    userRegistartionDto.setLastName(lname.getText().toString());
                    userRegistartionDto.setEmail(email_.getText().toString());
                    userRegistartionDto.setPassword(password_.getText().toString());
                    userRegistartionDto.setMobile(contact_n.getText().toString());

                    foody_api = API_Client.getRetrofit().create(Foody_API.class);
                    Call<LoginResponse> call = foody_api.UserSave(userRegistartionDto);
                    call.enqueue(new Callback<LoginResponse>() {
                        @Override
                        public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                            Toast.makeText(RegisterActivity.this, "Success", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Call<LoginResponse> call, Throwable t) {
                            Toast.makeText(RegisterActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
        }
        });

        signin_b=findViewById(R.id.signin_reg);
        signin_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });


    }
}
