package com.example.foody_mobile_app.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Food {
    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("name")
    @Expose
    private String name;

    @SerializedName("image")
    @Expose
    private String image;

    @SerializedName("designation")
    @Expose
    private String desc;

    @SerializedName("file_path")
    @Expose
    private String path;

    @SerializedName("price")
    @Expose
    private int price;

    @SerializedName("createdDate")
    @Expose
    private String createdDate;

    @SerializedName("file_name")
    @Expose
    private String fileName;

    public Food()
    {

    }

    public Food(String id, String name, String image, String desc, String path, int price, String createdDate, String fileName) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.desc = desc;
        this.path = path;
        this.price = price;
        this.createdDate = createdDate;
        this.fileName = fileName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String  getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}