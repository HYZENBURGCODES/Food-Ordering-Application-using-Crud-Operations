package com.example.foody_mobile_app.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foody_mobile_app.Model.Order;
import com.example.foody_mobile_app.R;

import java.util.ArrayList;

public class CompletedOrdersAdapter extends RecyclerView.Adapter<CompletedOrdersAdapter.ViewHolder>
{
    private ArrayList<Order> orderArrayList=new ArrayList<>();
    private Context context;

    public CompletedOrdersAdapter(ArrayList<Order> orderArrayList, Context context) {
        this.orderArrayList = orderArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public CompletedOrdersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view;
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        view=layoutInflater.inflate(R.layout.order_history_list,parent,false);
        CompletedOrdersAdapter.ViewHolder viewHolder=new CompletedOrdersAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CompletedOrdersAdapter.ViewHolder holder, int position)
    {
        String string_order_id=String.valueOf(orderArrayList.get(position).getOrder_id());
        String string_qunatity=String.valueOf(orderArrayList.get(position).getQnty());
        String string_total=String.valueOf(orderArrayList.get(position).getTotal());


        holder.order_id_View.setText(string_order_id);
        holder.address_view.setText(orderArrayList.get(position).getAddress());
        holder.date_view.setText(orderArrayList.get(position).getDate());
        holder.food_name_view.setText(orderArrayList.get(position).getFoodname());
        holder.qnty_viewview.setText(string_qunatity);
        holder.status_view.setText(orderArrayList.get(position).getStatus());
        holder.total_view.setText(string_total);

    }

    @Override
    public int getItemCount() {
        return orderArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView order_id_View;
        private TextView food_name_view;
        private TextView date_view;
        private TextView qnty_viewview;
        private TextView total_view;
        private TextView status_view;
        private TextView address_view;
        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            order_id_View=itemView.findViewById(R.id.new_order_id_history);
            food_name_view=itemView.findViewById(R.id.food_name_order_history);
            date_view=itemView.findViewById(R.id.date_order_history);
            qnty_viewview=itemView.findViewById(R.id.food_qnty_order_history);
            total_view=itemView.findViewById(R.id.food_total_order_history);
            status_view=itemView.findViewById(R.id.food_status_order_history);
            address_view=itemView.findViewById(R.id.food_dev_address_order_history);
        }
    }
}
