package com.example.foody_mobile_app.API;

import retrofit2.Call;

import com.example.foody_mobile_app.Model.ContactDto;
import com.example.foody_mobile_app.Model.Food;
import com.example.foody_mobile_app.Model.Order;
import com.example.foody_mobile_app.Model.OrderDto;
import com.example.foody_mobile_app.Model.Review;
import com.example.foody_mobile_app.Model.ReviewDto;
import com.example.foody_mobile_app.Model.User;
import com.example.foody_mobile_app.Model.UserRegistartionDto;
import com.example.foody_mobile_app.ResponseJson.LoginResponse;

import java.util.List;

import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Foody_API
{
    @POST("User/Register")
    Call<LoginResponse> UserSave(@Body UserRegistartionDto userRegistartionDto);

    @GET("login/{username}/{password}")
    Call<LoginResponse> getLoginResponse(@Path("username")String username, @Path("password")String password);

    @GET("User/foodlist")
    Call<List<Food>> getAllFoods();

    @GET("User/vieworders/{email}/{status}")
    Call<List<Order>> ViewCustomerOrders(@Path("email")String username,@Path("status")String status);

    @POST("User/addcontact")
    Call<Void> ComtactAdmin(@Body ContactDto contactDto);

    @POST("User/addreviews")
    Call<Void> AddReview(@Body ReviewDto reviewDto);

    @GET("User/reviewlist")
    Call<List<Review>> getAllReviews();

    @POST("User/placeorder")
    Call<Void> PlaceOrder(@Body OrderDto order);

    @GET("User/onthewayorders/{email}/{status}")
    Call<List<Order>> ViewOnTheWayOrders(@Path("email")String username,@Path("status")String status);

    @GET("User/completedorders/{email}/{status}")
    Call<List<Order>> ViewCompletedOrders(@Path("email")String username,@Path("status")String status);

    @POST("User/update")
    Call<Void> update_Order(@Body Order order);

}
