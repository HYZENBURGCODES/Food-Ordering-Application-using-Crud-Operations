package com.example.foody_mobile_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Model.Food;
import com.example.foody_mobile_app.Model.Order;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerViewOrdersActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{
    private Foody_API foody_api;
    private List<Order> orderArrayList=new ArrayList<>();
    GridView gridView;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_view_orders);

        gridView=findViewById(R.id.customer_order_gridview);
       // getOrdersByEmail();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        navigationView.setNavigationItemSelectedListener(this);

        Intent intent=getIntent();
        String email=intent.getStringExtra("email");
        String status= "Preparing";

        foody_api= API_Client.getRetrofit().create(Foody_API.class);
        Call<List<Order>> call=foody_api.ViewCustomerOrders(email,status);
        call.enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response)
            {
                if(response.isSuccessful())
                {
                    String message="successful";
                    Toast.makeText(CustomerViewOrdersActivity.this,message,Toast.LENGTH_SHORT).show();

                    orderArrayList=response.body();
                    CustomerViewOrdersActivity.OrderViewAdapter orderViewAdapter=new CustomerViewOrdersActivity.OrderViewAdapter(orderArrayList,CustomerViewOrdersActivity.this);
                    gridView.setAdapter(orderViewAdapter);
                }
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t)
            {
                Toast.makeText(CustomerViewOrdersActivity.this,"Order List Failed",Toast.LENGTH_SHORT).show();

            }
        });

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_cus_order);
        txtProfileName.setText(email);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

    }

    public class OrderViewAdapter extends BaseAdapter
    {
        private List<Order> orderList;
        private Context context;
        private LayoutInflater layoutInflater;

        public OrderViewAdapter(List<Order> orderList, Context context) {
            this.orderList=orderList;
            this.context = context;
            this.layoutInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return orderList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup)
        {
            if(view==null)
            {
                view=layoutInflater.inflate(R.layout.customer_order_list_item,viewGroup,false);

            }
            TextView order_id_View=view.findViewById(R.id.new_order_id);
            TextView food_name_view=view.findViewById(R.id.food_name_order);
            TextView date_view=view.findViewById(R.id.date_order);
            TextView qnty_viewview=view.findViewById(R.id.food_qnty_order);
            TextView total_view=view.findViewById(R.id.food_total_order);
            TextView status_view=view.findViewById(R.id.food_status_order);
            TextView address_view=view.findViewById(R.id.food_dev_address_order);

            String string_order_id=String.valueOf(orderArrayList.get(i).getOrder_id());
            String string_qunatity=String.valueOf(orderArrayList.get(i).getQnty());

            order_id_View.setText(string_order_id);
            total_view.setText("Rs."+orderList.get(i).getTotal()+".00");
            food_name_view.setText(orderList.get(i).getFoodname());
            date_view.setText(orderList.get(i).getDate());
            qnty_viewview.setText(string_qunatity);
            status_view.setText(orderList.get(i).getStatus());
            address_view.setText(orderList.get(i).getAddress());
            return view;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.customer_view_orders, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {

        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(CustomerViewOrdersActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));;
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerViewOrdersActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerViewOrdersActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerViewOrdersActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerViewOrdersActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerViewOrdersActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerViewOrdersActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
