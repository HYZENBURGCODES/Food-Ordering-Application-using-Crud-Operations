package com.example.foody_mobile_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.foody_mobile_app.API.API_Client;
import com.example.foody_mobile_app.API.Foody_API;
import com.example.foody_mobile_app.Adapter.ViewAllReviewsAdapter;
import com.example.foody_mobile_app.Model.Food;
import com.example.foody_mobile_app.Model.Review;
import com.example.foody_mobile_app.Model.ReviewDto;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.NamespaceContext;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerReadReviewsActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener
{
    private Foody_API foody_api;
    ArrayList<Review> reviewArrayList=new ArrayList<>();
    private RecyclerView AllReviewsRecyclerView;
    private AppBarConfiguration mAppBarConfiguration;
    private ViewAllReviewsAdapter viewAllReviewsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_read_reviews);

       AllReviewsRecyclerView=findViewById(R.id.customer_read_review_view);
       AllReviewsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

       getReviewList();

       Intent receive_email= getIntent();
       String email=receive_email.getStringExtra("email");

       Toolbar toolbar = findViewById(R.id.toolbar);
       setSupportActionBar(toolbar);
       DrawerLayout drawer = findViewById(R.id.drawer_layout);
       NavigationView navigationView = findViewById(R.id.nav_view);
       drawer = findViewById(R.id.drawer_layout);
       navigationView.setNavigationItemSelectedListener(this);

        TextView txtProfileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.textView_read_reviews);
        txtProfileName.setText(email);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.customer_read_reviews, menu);
        return true;
    }

    private void getReviewList()
    {
        foody_api= API_Client.getRetrofit().create(Foody_API.class);
        Call<List<Review>> call=foody_api.getAllReviews();
        call.enqueue(new Callback<List<Review>>() {
            @Override
            public void onResponse(Call<List<Review>> call, Response<List<Review>> response)
            {
                if(response.isSuccessful())
                {
                    String message="successful";
                    Toast.makeText(CustomerReadReviewsActivity.this,message,Toast.LENGTH_SHORT).show();
                    reviewArrayList= new ArrayList<>(response.body());
                    viewAllReviewsAdapter=new ViewAllReviewsAdapter(reviewArrayList,CustomerReadReviewsActivity.this);
                    AllReviewsRecyclerView.setAdapter(viewAllReviewsAdapter);
                }
            }

            @Override
            public void onFailure(Call<List<Review>> call, Throwable t)
            {
                Toast.makeText(CustomerReadReviewsActivity.this,"List Loading Failed",Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.navigation_home:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerHomeActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_orders:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerViewOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_contact:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerContactActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_addreview:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerAddReviewActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_read_review:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerReadReviewsActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_ontheway_orders:
                startActivity(new Intent(CustomerReadReviewsActivity.this,OntheWayOrdersActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_completed_orders:
                startActivity(new Intent(CustomerReadReviewsActivity.this,CustomerOrderHistoryActivity.class).putExtra("email",getIntent().getStringExtra("email")));
                break;
            case R.id.navigation_logout:
                startActivity(new Intent(CustomerReadReviewsActivity.this,LoginActivity.class));
                break;
        }
        return false;
    }
}
