package com.example.foody_mobile_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OrderReceiptActivity extends AppCompatActivity
{
    private TextView foodnametextview,qntytextview,toaltextview,addresstextview;
    private Button return_home_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_receipt);

        final Intent intent=getIntent();
        final String food_name=intent.getStringExtra("foodname");
        final String email=intent.getStringExtra("email");
        final String address=intent.getStringExtra("address");
        final int quantity=intent.getIntExtra("qnty",0);
        final  int toal=intent.getIntExtra("total",0);

        foodnametextview=(TextView) findViewById(R.id.order_details_foodname);
        qntytextview=(TextView) findViewById(R.id.order_details_food_qnty);
        toaltextview=(TextView) findViewById(R.id.order_details_food_total);
        addresstextview=(TextView) findViewById(R.id.order_details_food_address);

        return_home_button=(Button) findViewById(R.id.order_details_return_home);

        String food_price=String.valueOf(quantity);
        String food_total=String.valueOf(toal);

        foodnametextview.setText(food_name);
        addresstextview.setText(address);
        qntytextview.setText(food_price);
        toaltextview.setText(food_total);

        return_home_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent home_intent=new Intent(OrderReceiptActivity.this,CustomerHomeActivity.class);
                home_intent.putExtra("email",email);
                startActivity(home_intent);
            }
        });
    }
}
